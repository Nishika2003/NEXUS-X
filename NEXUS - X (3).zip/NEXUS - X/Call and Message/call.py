from twilio.rest import Client
from geopy.geocoders import Nominatim

# Twilio account credentials
account_sid = "AC872d66de625d355fdcee00b0b4e7c219"
auth_token = "d5c031818fb710c8c753f7f5413f8a63"

# Twilio phone number and recipient's phone number
twilio_number = "+13204088278"
recipient_number = "+916303082900"

# Initialize Twilio client
client = Client(account_sid, auth_token)

def get_location(latitude, longitude):
    geolocator = Nominatim(user_agent="location_finder")
    location = geolocator.reverse(f"{latitude}, {longitude}")
    return location.address

# Dummy coordinates
latitude = 37.7749
longitude = -122.4194

# Get current location
current_location = get_location(latitude, longitude)

# Compose the message
message_body = f"My current location is: {current_location}"

# Send the message
message = client.messages.create(
   body=message_body,
   from_=twilio_number,
   to=recipient_number
)

##print(f"Message sent with SID: {message.sid}")

# Make a call
call = client.calls.create(
    url='http://demo.twilio.com/docs/voice.xml',
    from_=twilio_number,
    to=recipient_number
)

print(f"Call made with SID: {call.sid}")
