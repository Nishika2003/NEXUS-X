import serial
import subprocess

ser = serial.Serial('COM11', 9600)  # Replace 'COM3' with the appropriate port

while True:
    if ser.in_waiting > 0:
        message = ser.readline().decode().strip()
        if message == "Button pressed!":
            # Execute your desired Python code here
            subprocess.run(["python", "1.py"])  # Replace "your_script.py" with your Python script filename
