import serial
import subprocess

# Define the Arduino's serial port and baud rate
serial_port = "COM11" # Update with your Arduino's serial port
baud_rate = 9600

# Open the serial connection
ser = serial.Serial(serial_port, baud_rate)

while True:
    # Read from the serial port
    if ser.readable():
        data = ser.read().decode().strip()

        # Check if the Arduino signaled to run the Python script
        if data == '1':
            print("Running Python script...")
            
            # Replace 'python_script.py' with your Python script's file name
            subprocess.run(['python', 'python_script.py'])
