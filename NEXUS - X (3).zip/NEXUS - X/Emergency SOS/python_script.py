from twilio.rest import Client
import requests
import json
account_sid = 'AC3f97c2e862cca3e76836ec0e0f4cd175'
auth_token = '3e37d838e9ae54da30e769c4b8b42767'
twilio_phone_number = '+13613269305'
recipient_number = '+916393193541'  # Replace with the recipient's phone number

# Initialize Twilio client
client = Client(account_sid, auth_token)

# Send a message
message = client.messages.create(
    body='Hello, this is a test message from Twilio!',
    from_=twilio_phone_number,
    to=recipient_number
)
print(f"Message SID: {message.sid}")

# Make a phone call
call = client.calls.create(
    twiml='<Response><Say>Hello, this is a test call from Twilio!</Say></Response>',
    to=recipient_number,
    from_=twilio_phone_number
)
print(f"Call SID: {call.sid}")
